package com.zybooks.studyhelpergame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class GameChooserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_chooser);
    }

    public void launchTicTacToe(View view)
    {
        Intent launchRaceGame = new Intent(this, TicTacToe_Activity.class);
        startActivity(launchRaceGame);

    }


    public void launchRaceGame(View view)
    {
        Intent launchRaceGame = new Intent(this, RaceGameActivity.class);
        startActivity(launchRaceGame);

    }

}
